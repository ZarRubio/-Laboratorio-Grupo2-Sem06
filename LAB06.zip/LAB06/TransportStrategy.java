package LAB06;

public interface TransportStrategy {
	
	void enviarPaquete(String paquete);
}
