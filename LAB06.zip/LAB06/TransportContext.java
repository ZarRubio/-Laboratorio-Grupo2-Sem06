package LAB06;

public class TransportContext {

	private TransportStrategy transporte;



	public TransportContext(TransportStrategy transporte) {
        this.transporte= transporte;
    }

    void enviarPaquete(String paquete) {
    
        transporte.enviarPaquete("paquete");
    }
}
