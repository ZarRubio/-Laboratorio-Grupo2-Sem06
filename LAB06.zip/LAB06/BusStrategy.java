package LAB06;

public class BusStrategy implements TransportStrategy {
	
	   public void enviarPaquete(String paquete) {
	        System.out.println("Enviando paquete por bus: " + paquete);
	    }
}
