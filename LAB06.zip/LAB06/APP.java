package LAB06;

public class APP {
    public static void main(String[] args) {

    	TransportStrategy avion = new AvionStrategy();
    	TransportStrategy bus = new BusStrategy();
    	TransportStrategy auto = new AutoStrategy();

    	TransportContext ContextAvion = new TransportContext(avion);
    	TransportContext ContextBus = new TransportContext(bus);
    	TransportContext ContextpAuto = new TransportContext(auto);

    	ContextAvion.enviarPaquete("Paquete 1");
    	ContextBus.enviarPaquete("Paquete 2");
    	ContextpAuto.enviarPaquete("Paquete 3");
    }

}
