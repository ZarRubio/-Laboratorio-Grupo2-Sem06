package LAB06;

public class AutoStrategy implements TransportStrategy {
	 public void enviarPaquete(String paquete) {
	        System.out.println("Enviando paquete por auto: " + paquete);
	    } 
}
