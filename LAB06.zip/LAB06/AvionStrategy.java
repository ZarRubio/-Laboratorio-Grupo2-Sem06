package LAB06;

public class AvionStrategy implements TransportStrategy {

	 public void enviarPaquete(String paquete) {
	        System.out.println("Enviando paquete por avión: " + paquete);
	    } 
}
